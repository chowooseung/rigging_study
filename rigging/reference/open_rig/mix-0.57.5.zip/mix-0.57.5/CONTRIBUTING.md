# Contributing

When contributing to this repository, please contact the contributors before making a pull request. When doing so, please include the issues being resolved or features being added. There is no gaurentee that unsolicited pull requests will be reviewed.
There is no guarentee that changes that will be added to this repository.
