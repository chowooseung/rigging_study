Credits
======= 
Original Authors
------------
* Walt Yoder
* Matt Schiller

Studios
------------
* [squarebit studios](http://www.squarebitstudios.com)

Contributors
------------
The following people have contributed to Mix.

Special Thanks
------------
The following people helped give feedback to Mix.
* Erik Hansen
* Joy Johnson