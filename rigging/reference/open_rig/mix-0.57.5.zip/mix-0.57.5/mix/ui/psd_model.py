'''
This is the default behavior for the psd models
'''
from mix.ui.abstract_graph_model import *
