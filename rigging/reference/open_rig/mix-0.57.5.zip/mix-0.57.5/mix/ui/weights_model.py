'''
Abstract model for default implementation
'''
from mix.ui.abstract_graph_model import *