Thank you for downloading this model hosted by Rigging Dojo and created by HippyDrome.

Usage:
Attribution to "HippyDrome.com" required for use.

About:

hippydrome.ma will open in Maya version 12 and later with out error.

hippydrome.fbx is 2010 compatible forward.

The two 2014 files are native to Maya and FBX 2014.